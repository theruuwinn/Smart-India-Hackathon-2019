<?php
		
	$con=mysqli_connect("127.0.0.1:3306","root","","autonomous statistical information collection system") or die(mysqli_connect_error());
		
?>