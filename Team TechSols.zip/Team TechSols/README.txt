1. The given software was made by keeping in mind the Apache (XAMPP) server.
2. PHP and mySQL integrated with the XAMPP server are used as primary backend programs.
3. The SQL database used is shared with the name: "autonomous_statistical_information_collection_system" and can be found in the folder "sql database".
4. All the files have been shared in the folder labelled "Project". The Main page can be found in the folder "DSDD AdminDashboard" under "Admin_html_file".
5. "login.html" is the referanced home page and all the pages can be navigated henceforth.
6. Valid Username for login is: "admin@admin.com".
7. Valid Password for login is: "admin123"
6. The following project is made by using open-source resources and only OFFICIAL softwares.
7. Python 3.6 is the basic requirement.
8. Following Python libraries are required to be installed before deploying the software:
	i.	Beautiful Soup
	ii.	numpy
	iii.	threading
	iv.	requests
	v.	smtplib
	vi.	urllib
	vii.	email
	viii.	pymysql
9. Downloaded files can be seen in XAMPP installation "htdocs" folder.
10. Minor Server configurations may be initially required to be configured, though most of the configs are default.