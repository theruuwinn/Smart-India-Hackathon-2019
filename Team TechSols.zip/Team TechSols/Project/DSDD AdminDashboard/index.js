document.getElementById("UserLogin").addEventListener('click',function(){

    window.location.replace("./User_html_files/userLogin.html");

});
document.getElementById("AdminLogin").addEventListener('click',function(){

    window.location.replace("./Admin_html_file/login.html");

});