-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 03, 2019 at 12:35 PM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `autonomous statistical information collection system`
--

-- --------------------------------------------------------

--
-- Table structure for table `add_officer`
--

CREATE TABLE `add_officer` (
  `First_Name` varchar(30) NOT NULL,
  `Middle_Name` varchar(30) NOT NULL,
  `Last_Name` varchar(30) NOT NULL,
  `Email_Id` varchar(50) NOT NULL,
  `Password` varchar(30) NOT NULL,
  `Mobile_Number` bigint(10) NOT NULL,
  `Pin_Code` int(6) NOT NULL,
  `State` varchar(30) NOT NULL,
  `Country` varchar(5) NOT NULL DEFAULT 'INDIA'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `add_officer`
--

INSERT INTO `add_officer` (`First_Name`, `Middle_Name`, `Last_Name`, `Email_Id`, `Password`, `Mobile_Number`, `Pin_Code`, `State`, `Country`) VALUES
('Nitasha', '', 'Gupta', '17dcs018@charusat.edu.in', 'nitasha', 9409950925, 382424, 'gujarat', 'India'),
('Prince', '', 'Makwana', '17dcs027@charusat.edu.in', '', 9426836645, 765433, 'guj', 'India');

-- --------------------------------------------------------

--
-- Table structure for table `collected_data`
--

CREATE TABLE `collected_data` (
  `File_Name` varchar(250) NOT NULL,
  `URL` varchar(250) NOT NULL,
  `File_Link` varchar(250) NOT NULL,
  `Timestamp` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `collected_data`
--

INSERT INTO `collected_data` (`File_Name`, `URL`, `File_Link`, `Timestamp`) VALUES
('C9L3%20Nazism%20and%20Rise%20of%20Hitler.pdf', 'C:/xampp/htdocs/Server Documents/C9L3%20Nazism%20and%20Rise%20of%20Hitler.pdf', 'https://resume-13d69.firebaseapp.com/files/C9L3%20Nazism%20and%20Rise%20of%20Hitler.pdf', '2019-03-03 15:07:52.662796'),
('Resume.pdf', 'C:/xampp/htdocs/Server Documents/Resume.pdf', 'https://resume-13d69.firebaseapp.com/files/Resume.pdf', '2019-03-03 14:56:38.440713'),
('Third%20girl%20-%20Agatha%20Cristie.pdf', 'C:/xampp/htdocs/Server Documents/Third%20girl%20-%20Agatha%20Cristie.pdf', 'https://resume-13d69.firebaseapp.com/files/Third%20girl%20-%20Agatha%20Cristie.pdf', '2019-03-03 15:18:28.028999');

-- --------------------------------------------------------

--
-- Table structure for table `url_list`
--

CREATE TABLE `url_list` (
  `URL` varchar(200) NOT NULL,
  `Doc_type` varchar(20) NOT NULL DEFAULT 'pdf'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `url_list`
--

INSERT INTO `url_list` (`URL`, `Doc_type`) VALUES
('http://mospi.gov.in/', 'pdf'),
('https://resume-13d69.firebaseapp.com/', 'pdf'),
('https://www.facebook.com/', 'pdf'),
('https://www.google.com', 'pdf');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `add_officer`
--
ALTER TABLE `add_officer`
  ADD UNIQUE KEY `Email_Id` (`Email_Id`),
  ADD UNIQUE KEY `Mobile_Number` (`Mobile_Number`);

--
-- Indexes for table `collected_data`
--
ALTER TABLE `collected_data`
  ADD UNIQUE KEY `URL` (`URL`),
  ADD UNIQUE KEY `File_Link` (`File_Link`);

--
-- Indexes for table `url_list`
--
ALTER TABLE `url_list`
  ADD PRIMARY KEY (`URL`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
