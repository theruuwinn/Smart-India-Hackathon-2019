
(function(){
// Initialize Firebase
    let config = {
        apiKey: "AIzaSyAaFE4g_aQjbjuoX6jQwaxzNLtFDDUPDbA",
        authDomain: "admindashboard-facb2.firebaseapp.com",
        databaseURL: "https://admindashboard-facb2.firebaseio.com",
        projectId: "admindashboard-facb2",
        storageBucket: "admindashboard-facb2.appspot.com",
        messagingSenderId: "684039194766"
    };
    firebase.initializeApp(config);

    app_fireBase = firebase;
}());